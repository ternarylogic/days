# Day 1: April Chill

A self-portrait on film.  
A few guitar notes for Kuzya’s Song.  
And this haiku:

Sudden April chill.  
Old lady selling lemons  
Comes here every night.
